from __future__ import absolute_import
from .celery_task import app as celery_app